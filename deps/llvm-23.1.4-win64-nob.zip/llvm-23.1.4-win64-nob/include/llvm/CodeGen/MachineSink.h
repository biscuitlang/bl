//===- MachineSink.h --------------------------------------------*- C++ -*-===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef LLVM_CODEGEN_MACHINESINK_H
#define LLVM_CODEGEN_MACHINESINK_H

#include "llvm/CodeGen/MachinePassManager.h"

namespace llvm {

class MachineSinkingPass : public OptionalPassInfoMixin<MachineSinkingPass> {
  bool EnableSinkAndFold;

public:
  MachineSinkingPass(bool EnableSinkAndFold = false)
      : EnableSinkAndFold(EnableSinkAndFold) {}

  LLVM_ABI PreservedAnalyses run(MachineFunction &MF,
                                 MachineFunctionAnalysisManager &);

  LLVM_ABI void
  printPipeline(raw_ostream &OS,
                function_ref<StringRef(StringRef)> MapClassName2PassName);
};

} // namespace llvm
#endif // LLVM_CODEGEN_MACHINESINK_H
