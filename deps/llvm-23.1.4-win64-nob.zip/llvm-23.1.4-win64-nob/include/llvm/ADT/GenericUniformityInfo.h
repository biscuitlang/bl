//===- GenericUniformityInfo.h ---------------------------*- C++ -*--------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef LLVM_ADT_GENERICUNIFORMITYINFO_H
#define LLVM_ADT_GENERICUNIFORMITYINFO_H

#include "llvm/ADT/GenericCycleInfo.h"
#include "llvm/Support/raw_ostream.h"

namespace llvm {

class TargetTransformInfo;

template <typename ContextT> class GenericUniformityAnalysisImpl;
template <typename ImplT> struct GenericUniformityAnalysisImplDeleter {
  // Ugly hack around the fact that recent (> 15.0) clang will run into an
  // is_invocable() check in some GNU libc++'s unique_ptr implementation
  // and reject this deleter if you just make it callable with an ImplT *,
  // whether or not the type of ImplT is spelled out.
  using pointer = ImplT *;
  void operator()(ImplT *Impl);
};

template <typename ContextT> class GenericUniformityInfo {
public:
  using BlockT = typename ContextT::BlockT;
  using FunctionT = typename ContextT::FunctionT;
  using ValueRefT = typename ContextT::ValueRefT;
  using ConstValueRefT = typename ContextT::ConstValueRefT;
  using UseT = typename ContextT::UseT;
  using InstructionT = typename ContextT::InstructionT;
  using DominatorTreeT = typename ContextT::DominatorTreeT;
  using ThisT = GenericUniformityInfo<ContextT>;

  using CycleInfoT = GenericCycleInfo<ContextT>;
  using CycleT = typename CycleInfoT::CycleT;

  using TemporalDivergenceTuple =
      std::tuple<ConstValueRefT, InstructionT *, const CycleT *>;

  GenericUniformityInfo(const DominatorTreeT &DT, const CycleInfoT &CI,
                        const TargetTransformInfo *TTI = nullptr);
  GenericUniformityInfo() = default;
  GenericUniformityInfo(GenericUniformityInfo &&) = default;
  GenericUniformityInfo &operator=(GenericUniformityInfo &&) = default;

  void compute() {
    DA->initialize();
    DA->compute();
  }

  /// The GPU kernel this analysis result is for
  const FunctionT &getFunction() const;

  /// Whether \p V is divergent at its definition.
  bool isDivergentAtDef(ConstValueRefT V) const;

  /// Whether \p V is uniform/non-divergent at its definition.
  bool isUniformAtDef(ConstValueRefT V) const { return !isDivergentAtDef(V); }

  // Whether the terminator instruction \p I is uniform/divergent, i.e. whether
  // the controlling condition of a conditional branch or switch is
  // uniform/divergent.
  // TODO: The comment below is now out of date:
  // These accept a pointer argument so that
  // in LLVM IR, they overload the equivalent queries for Value*. For example,
  // if querying whether a CondBrInst is divergent, it should not be treated as
  // a Value in LLVM IR.
  bool isUniformTerminator(const InstructionT *I) const {
    return !isDivergentTerminator(I);
  };
  bool isDivergentTerminator(const InstructionT *I) const;

  /// \brief Whether \p U is divergent at its use. Uses of a uniform value can
  /// be divergent.
  bool isDivergentAtUse(const UseT &U) const;

  /// \brief Whether \p U is uniform/non-divergent at its use.
  bool isUniformAtUse(const UseT &U) const { return !isDivergentAtUse(U); }

  bool hasDivergentTerminator(const BlockT &B);

  void print(raw_ostream &Out) const;

  iterator_range<TemporalDivergenceTuple *> getTemporalDivergenceList() const;

private:
  using ImplT = GenericUniformityAnalysisImpl<ContextT>;

  std::unique_ptr<ImplT, GenericUniformityAnalysisImplDeleter<ImplT>> DA;

  GenericUniformityInfo(const GenericUniformityInfo &) = delete;
  GenericUniformityInfo &operator=(const GenericUniformityInfo &) = delete;
};

} // namespace llvm

#endif // LLVM_ADT_GENERICUNIFORMITYINFO_H
