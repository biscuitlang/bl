//===-- llvm/Analysis/Lint.h - LLVM IR Lint ---------------------*- C++ -*-===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//
//
// This file defines lint interfaces that can be used for some validation of
// input to the system, and for checking that transformations haven't done
// something bad. In contrast to the Verifier, the Lint checker checks for
// undefined behavior or constructions with likely unintended behavior.
//
// To see what specifically is checked, look at Lint.cpp
//
//===----------------------------------------------------------------------===//

#ifndef LLVM_ANALYSIS_LINT_H
#define LLVM_ANALYSIS_LINT_H

#include "llvm/IR/PassManager.h"

namespace llvm {

class Module;
class Function;

/// Lint a module.
///
/// This should only be used for debugging, because it plays games with
/// PassManagers and stuff.
LLVM_ABI void lintModule(const Module &M, bool AbortOnError = false);

// Lint a function.
LLVM_ABI void lintFunction(const Function &F, bool AbortOnError = false);

class LintPass : public RequiredPassInfoMixin<LintPass> {
  const bool AbortOnError;

public:
  LintPass(bool AbortOnError) : AbortOnError(AbortOnError) {}
  LLVM_ABI PreservedAnalyses run(Function &F, FunctionAnalysisManager &AM);

  LLVM_ABI void
  printPipeline(raw_ostream &OS,
                function_ref<StringRef(StringRef)> MapClassName2PassName);
};

} // namespace llvm

#endif // LLVM_ANALYSIS_LINT_H
